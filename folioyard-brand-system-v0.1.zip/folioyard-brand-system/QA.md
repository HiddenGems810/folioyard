# Folioyard Brand System v0.1 / QA evidence

Date: 2026-10-12  
Scope: Visual brand preview and token package only. PDF processing is not in scope.

## Verified locally

- JSON token source parses successfully.
- CSS semantic light/dark aliases are defined and used by the workspace specimen.
- Desktop screen at 1440px: preview renders. Mobile at 390px and 320px and tablet at 768px: `scrollWidth === viewportWidth` (no horizontal overflow).
- Runtime page errors: none observed in tested browser runs.
- Theme-switcher interaction: workspace `data-theme` updates to dark.
- Sample primary button: updates visible demonstration feedback text (not a PDF operation).
- Light-mode document workflow specimen and dark-mode specimen manually inspected.
- Color contrast manually calculated from specified palette: ink/paper 12.95:1, mist/paper 4.63:1, strong coral/paper 6.18:1, coral/paper 2.90:1.

## Unverified / not claimed

- Production webfont loading was not reliably benchmarked in isolated browser QA; the fallback typography rendered and was reviewed.
- Real PDF transformations, file security, file upload privacy, any back-end service, production mobile UX, full WCAG audit, analytics, performance, localization, or screen reader behavior.
- Official legal trademark/domain/business conflict clearance.
- Final logo approval or optical tests at favicon sizes.

## Evidence artifacts

Standalone preview and screenshots are delivered alongside this package. Testing runs used Chromium through Playwright. Screenshot dimensions and capture environments do not establish cross-browser performance or product readiness.
