# Folioyard Brand System v0.1

**Provisional brand identity and implementation kit for a free, privacy-first PDF workspace.**

## Open first

`preview/index.html` is the brand showcase. It is responsive and includes a light/dark product UI specimen. This is a **visual prototype**, not working PDF software.

For a standalone copy outside the folder, use the accompanying `folioyard-brand-preview.html` artifact.

## Files

```text
folioyard-brand-system/
├── README.md
├── brand-guide.md
├── QA.md
├── assets/
│   ├── folioyard-icon.svg
│   ├── folioyard-icon-on-light.svg
│   ├── folioyard-symbol-one-color.svg
│   └── folioyard-favicon.svg
├── tokens/
│   ├── folioyard.tokens.json      # structured source of truth
│   ├── folioyard.css              # theme-aware CSS custom properties
│   └── folioyard.ts               # typed values for TS apps
└── preview/
    └── index.html                # self-contained visual showcase
```

## Integrate with Next.js / Vite / React

1. Add `tokens/folioyard.css` to your global CSS import.
2. Set `<html data-theme="light">` or `data-theme="dark"`; both modes are explicitly defined.
3. Use `var(--fy-color-canvas)`, `var(--fy-color-surface)`, `var(--fy-color-text)`, `var(--fy-color-action)`, `var(--fy-color-action-text)`, `var(--fy-color-border)`, and `var(--fy-color-focus)` in components.
4. Use `fy` from `tokens/folioyard.ts` if JS constants are needed. Prefer CSS theme aliases for rendered components.
5. Load Instrument Sans and IBM Plex Mono through an appropriately licensed web font delivery method; the preview uses Google Fonts. Don't redistribute font binaries from this kit.
6. Introduce tokens gradually rather than copying the showcase's sample UI code wholesale; a component library needs real focus, validation, upload, and error-state semantics.

### Example

```tsx
import './tokens/folioyard.css';

export function PrimaryAction() {
  return <button className="fy-button fy-button--primary">Export PDF</button>;
}
```

### Theme toggle

```ts
document.documentElement.dataset.theme = 'dark';
```

## Product and rights status

- Name: **provisional**, not legally/trademark cleared.
- Identity: **direction 01**, not final approved master.
- SVGs: original editable vector concepts. Live wordmark is *not* an outlined vector logo.
- Preview: working theme and sample controls for identity inspection; no real PDF operations.
- Brand promises (privacy and free functionality) are *requirements*, not verified product facts.

See `brand-guide.md` for full design governance and `QA.md` for the evidence and limitations.
