# Folioyard / Brand system v0.1

**Status:** proposed identity, October 12, 2026. Not a legal clearance, approved final logo, deployed product, or tested PDF engine.

## 1. Strategic thesis

**Brand:** folioyard.  
**Descriptor:** Free PDF tools.  
**Positioning:** A quiet, private-first workbench where anyone can finish routine PDF tasks without friction, confusing upsells, or avoidable account creation.  
**Tagline:** *Less friction. More finished.*

### Brand beliefs

- **Clarity is a feature.** The next action should be unmistakable.
- **Documents take priority.** The PDF must dominate the working area, not the product chrome.
- **Ownership matters.** Implement local processing where practical and clearly disclose any server-side processing. Do not claim files stay on-device until the code and network behavior prove it.
- **Free should be usable.** Avoid arbitrary subscription gates for core PDF tasks. External processing and storage costs still need explicit operating budgets.

### Intended audience

Students, independent professionals, creators, small business owners, and people who simply need to finish a document. Designed for users who do not want to learn a complex editor for a one-time task.

### Voice

- Plain verbs: **Merge PDFs**, **Compress PDF**, **Add signature**, **Export file**.
- Concrete, concise feedback: “Your PDF is ready” after verified success; “This file is password-protected” after validation.
- Never use: “unlock the magic,” “supercharge your productivity,” “AI-powered brilliance,” artificial urgency, or exaggerated privacy promises.
- Error messages name what failed, preserve user work where possible, and give a recoverable next action.
- Provide file-specific metadata where it helps: page count, size, selected pages, output estimate if verifiable.

## 2. Design grammar

**Visual thesis:** A modern document workbench rather than a crowded tools directory. Restrained editorial hierarchy, pragmatic geometry, warm surfaces, generous whitespace, and precise status annotations.

**Composition:**

- **Marketing:** oversized, disciplined typography; asymmetrical hero with a document object; calm color blocks; no stock SaaS gradients.
- **Product:** left-side tool navigation on desktop; focused document stage; one primary call to action; shallow, comprehensible panels.
- **Mobile:** document action first; replace dense sidebar with compact navigation instead of simply squeezing the desktop workspace.
- **Grid:** max-width 1280px; maximum editorial reading width 840px; responsive with 18px mobile / 36px desktop page gutters in the visual proof.
- **Density:** marketing spacious; application moderately compact; metadata on mono secondary tier.
- **Shape:** mostly 8px and 12px radii. The 16px/24px radii are reserved for larger panels, not every control.

### Signature interaction proposal

**Document-to-workspace transition.** When a valid PDF is selected, the drop area transitions into a document preview with page count and the immediately relevant available actions. Use opacity/transform where practical; under reduced motion, replace the transition with an instant accessible state change. No theatrical scroll-trapping.

## 3. Color system

| Role | Token | Hex | Use |
|---|---|---|---|
| Foundation | `primitive.color.ink` | `#1C302C` | Brand text, primary light-mode action, deep backgrounds |
| Paper | `primitive.color.paper` | `#F7F7F2` | Main light-mode canvas |
| Accent | `primitive.color.coral` | `#E66F4E` | Locator dot, emphasis, progress marks, selected decorative highlights |
| Accent readable | `primitive.color.coralStrong` | `#9B402A` | Coral-hued text on light backgrounds |
| Depth | `primitive.color.spruce` | `#284D43` | Hover, dark secondary surfaces |
| Tint | `primitive.color.sage` | `#E9EFE8` | Gentle selected states and noncritical highlights |
| Muted text | `primitive.color.mist` | `#64736E` | Supporting light-mode labels, 4.63:1 on paper |
| Border | `primitive.color.line` | `#D8DED6` | Noncritical separators, not meaningful text |
| Success | `primitive.color.success` | `#207353` | Confirmed, recoverable completed states |
| Warning | `primitive.color.warning` | `#855819` | User-action-needed alerts |
| Danger | `primitive.color.danger` | `#B63830` | Failed validation and destructive actions |

**Contrast baseline:** text on paper: ink 12.95:1, mist 4.63:1, strong coral 6.18:1. Bright coral on paper is ~2.90:1; it is *not* allowed as body text or a standalone status indication. Test all new color pairs; opaque border colors need not meet text contrast unless they convey essential component boundaries.

**Semantic design:** Consume `semantic.light.color` and `semantic.dark.color` aliases (or generated CSS `--fy-color-*`). Never use primitives directly for component theme roles if a semantic alias exists. Dark mode is intentionally ink-dominant, not gray-and-neon.

## 4. Typography

**Instrument Sans:** display, headings, body text, buttons, and navigation.  
**IBM Plex Mono:** metadata, counters, technical labels, file sizes, timestamps.

Both families are referenced through the Google Fonts CSS API in the preview, with explicit fallback fonts. Fonts are **not embedded or redistributed** in this kit. Confirm the license and self-hosting plan before production.

- Display desktop: 88px / 600 / leading 1.02 / tracking approx −0.075em (context-specific; use negative tracking only for display).
- H1 desktop: 64px / 600 / leading 1.02.
- H2 desktop: 44px or 32px / 600 / leading 1.1.
- Body standard: 16px / 400 / leading 1.5.
- Body small: 14px / 400 / leading 1.5.
- Utility metadata: 12px / 500 / leading 1.4; use uppercase selectively, never for paragraphs.
- Browser font swaps and long-language content require retesting.

## 5. Symbol and wordmark

**Provisional icon concept:** an abstract F composed of stacked page planes and a coral locator tile. Geometry is authored as editable SVG, not an AI-generated raster or recreated screenshot. All icon copies in this folder currently have **concept** status.

- **Primary wordmark treatment:** lowercase **folioyard.** in Instrument Sans, semibold, optical tracking approx `-0.065em`. Terminal dot uses Folio Coral.
- **Wordmark source status:** live text, not an approved, outlined vector master. Do not represent it as one.
- **Proposed favicon minimum:** 24px. Test at 16/24/32/48px before approval and redraw if readability fails.
- **Safe area:** start at 25% of the icon's width on each side; adjust after optical inspection.
- **Variants:** evergreen tile with warm-paper F/coral locator; one-color symbol for accessible restricted-color contexts.
- **Do not:** recolor the accent arbitrarily, distort proportions, add glow, clone marks of other software, or assume domain/trademark clearance.

## 6. Core primitives

- Spacing: 4px cadence with explicit tokens `0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 14, 16, 20, 24`.
- Radii: `xs 4px / sm 8px / md 12px / lg 16px / xl 24px / pill 999px`.
- Motion durations: `fast 140ms / base 220ms / slow 360ms` and ease `.2, .8, .2, 1`.
- Components: 44px minimum primary button/input height; icon buttons must also satisfy appropriate target-size requirements and accessible names.
- Focus: high-contrast visible 3px ring with offset. Never remove focus indication.
- Depth: keep shadows reserved for real layer separation; no glassmorphism or gratuitous elevation.
- States: idle, hover, focus, drag-over, validating, processing, ready, failed, cancel, downloadable. Each meaningful state must have accessible text (not color alone).

## 7. Product UI priorities

**First build scope proposed:** Merge, split, rotate, reorder, and compress PDFs; export/download. Compression needs transparent quality choices and realistic size estimates only when calculable. Signature and conversion can follow once local-first feasibility and correct output are verified.

- Workflow: select files → validate type/size/encryption → show file state/page preview → configure transform → process → verify output → export → revoke temporary object URLs/clear sensitive memory.
- Errors: malformed/encrypted inputs, empty pages, oversized memory demand, interrupted processing, browser tab reload, unsupported conversion.
- Privacy: no unexpected uploads, no service worker caching of personal document bytes, no analytics capturing file names/content, no persistent storage without explicit choice.
- Accessibility: semantic controls, keyboard import/export, action announcements, sufficient contrast, zoom/reflow, reduced motion.
- Operational claim: the supplied HTML is a **brand and interface preview only**. PDF functionality is not connected.

## 8. Production asset governance

| Asset | Location | Status |
|---|---|---|
| Editable core symbol | `assets/folioyard-icon.svg` | Direction 01 / provisional |
| Light surface variant | `assets/folioyard-icon-on-light.svg` | Direction 01 / provisional |
| One-color symbol | `assets/folioyard-symbol-one-color.svg` | Direction 01 / provisional |
| Favicon | `assets/folioyard-favicon.svg` | Provisional; test at 16px |
| Primary wordmark | Live type specimen in HTML | Not an outlined vector master |
| Preview art/document | Inline HTML/SVG/CSS | Synthetic demonstration, not user data |
| Design tokens | `tokens/folioyard.tokens.json` | Source of truth / v0.1 |
| CSS semantic aliases | `tokens/folioyard.css` | Generated implementation file |
| Typed app mapping | `tokens/folioyard.ts` | Generated implementation file |

No real client data, customers, unlicensed external images, or approval claims are included.

## 9. Open decisions and release gates

1. Confirm Folioyard domain availability and trademark clearance before public launch.
2. Approve or revise the F symbol after 16/24/32px legibility review.
3. Decide whether to commission a custom outlined wordmark or approve a font-based live text lockup.
4. Validate all component semantics/contrast against WCAG 2.2 AA in the actual built app, in both themes.
5. Test the actual PDF pipeline (local processing, memory, performance, corruption, encryption, output validity) before making privacy/functionality claims.
6. Test responsive UX at **320, 375, 390, 430, 768, 1200, 1440, 1728px**, including zoom/reflow and reduced motion.

### Critical design risk

Many developer utilities look beautiful for one hero screenshot and become unusable when a user selects a 64-page document. Keep the *document lifecycle* as the center of the component architecture, not the marketing mockup.
